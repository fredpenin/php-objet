<?php 
// On inclue le fichier header.php sur la page :
require_once(__DIR__ . '/partials/header.php'); ?>


    <main class="container">
        <h1>VTC</h1>
        <br /><br />
        <h5>Gestion de véhicules et de leur propriétaire</h5>
    </main>


    <?php 
// On inclue le fichier footer.php sur la page :
require_once(__DIR__ . '/partials/footer.php'); ?>